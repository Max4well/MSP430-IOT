/*
 * mqtt.h
 *
 *  Created on: May 12, 2022
 *      Author: Burak Duysak
 */

#ifndef MQTT_H_
#define MQTT_H_


void Connect_to_Wifi();
void Connect_to_Broker();
void publish(char *topic, char *message);

#endif /* MQTT_H_ */
