#include <msp430g2553.h>
#include <string.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "lcd.h"
#include "uart_serial.h"
#include "delay.h"
#include "mqtt.h"

void adc_init(void);//ADC kurulum


void lcd_sayi_yaz(unsigned int);//LCD INT yazdiran fonk.





unsigned short wADCHam[4];//ADC Verileri tutan dizi.

unsigned int tim,avg_counter=0,dataflag=0,i=0,kontrol_main=0;
long int avg_vol=0,avg_temp=0;
unsigned char b[4];



void main()
{
    WDTCTL = WDTPW + WDTHOLD;//Watchdog timer off.
    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL = CALDCO_1MHZ;//1MHz Clock used

        _BIS_SR(GIE);  // Enable interrupts
        CCTL0 = ~CCIE;      // CCR0 interrupt disabled
        TACTL = TASSEL_2 + MC_2; // SMCLK/8, upmode
        CCR0 =  50000; // 1hz
        adc_init();//ADC Kurulum ayarlari �agrildi.
        serialInit();//Seri iletisim 115200baudrate ayarlandi.
        lcd_init();//lcd hazirlandi.
        lcd_go_line(1);
        delay_ms(1000);
        SerialPrint("AT\r\n");//Esp iletisim testi.
        IE2|=UCA0RXIE;
        delay_ms(100);
        if(!Serialfind_OK()){
            SerialPrint("AT\r\n");//Esp iletisim testi.
            delay_ms(1000);
        }
             lcd_write("ESP baglandi.");
             SerialPrint("AT+CWMODE=1\r\n");//ESP istemci modu olarak ayarlandi.
             delay_ms(1000);
             Connect_to_Wifi();//Connect_to_Wifi
             clr_rxbuff();
             lcd_yeniden();
             lcd_write("Aga baglaniyor.");
              while(!Serialfind_OK())  //6 saniye boyunca baglanmayi bekle.
             {
               kontrol_main++;
               IE2|=UCA0RXIE;
               if(kontrol_main==1400)
               {
                   kontrol_main=0;
                 lcd_yeniden();
                 lcd_write("Aga baglanmadi!!");
                 lcd_go_line(2);
                 lcd_write("Yeniden Baslat");
                 Connect_to_Wifi();
               }
              delay_ms(5);
             }
             lcd_yeniden();
             lcd_write("Aga baglandi.");
             lcd_go_line(2);
 //            lcd_write(ag_ismi);
             clr_rxbuff();
             delay_ms(2000);
             Connect_to_Broker();
             publish("g40temp","23");



}
// Timer A0 interrupt service routine
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{
  i++;

  if(i==20)
  {
    __bic_SR_register_on_exit(CPUOFF);//Cpu uyandir.
    i=0;
  }
}


#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
__bic_SR_register_on_exit(CPUOFF); // Islemciyi uykudan uyandir.
}


void adc_init(void)
{
        ADC10CTL1 = INCH_3 + CONSEQ_3; // A3-A0, tekrarli �oklu kanal
        ADC10CTL0 = ADC10SHT_2 + MSC + ADC10ON + ADC10IE; // Kesme aktif, �oklu kanal
        ADC10AE0 = BIT0 + BIT3; // A0, A3 ADC �zelligini aktif et
        ADC10DTC1 = 0x04; // Toplamda her seferinde 4 �evrim yapilacak

}





void lcd_sayi_yaz(unsigned int temp)
{       lcd_yeniden();
    b[1]=temp%10;
        b[0]=temp/10;
        lcd_yeniden();
        lcd_write("Kalan sure:");
        lcd_char(b[0]+48);
        lcd_char(b[1]+48);
    lcd_write("sn");

}

void integer_yaz(unsigned int deger)
{
  lcd_char( deger/1000+48);
  lcd_char((deger%1000)/100+48);
  lcd_char((deger%100)/10+48);
  lcd_char((deger)%10+48);
  lcd_write(".");
}

