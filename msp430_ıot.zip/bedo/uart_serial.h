/*
 * uart_serial.h
 *
 *  Created on: May 12, 2022
 *      Author: Burak Duysak
 */

#ifndef UART_SERIAL_H_
#define UART_SERIAL_H_


extern volatile unsigned char rxbuffer[50];//Seri ekrandan gelen verileri tutan dizi
extern volatile unsigned char rx_buffer[50],tx_buffer[150];

void serialInit();
void SerialPrintc(unsigned char c);
void SerialPrint(const char *str);
unsigned int Serialfind_packetready(void);
unsigned int Serialfind_OK(void);
unsigned int Serialfind_IP(void);
void clr_rxbuff(void);
#endif /* UART_SERIAL_H_ */
