/*
 * uart_serial.c
 *
 *  Created on: May 12, 2022
 *      Author: BURAK DUYSAK
 */
#include <msp430g2553.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "uart_serial.h"

unsigned int w = 0; // counter for recieve buffer

volatile unsigned char rxbuffer[50];//Seri ekrandan gelen verileri tutan dizi
volatile unsigned char rx_buffer[50],tx_buffer[150];

void serialInit()
{
    P1SEL= BIT1 + BIT2; //P1.1 = RXD P1.2=TXD
    P1SEL2= BIT1 +BIT2; // P1.1=RXD & P1.2=TXD
    UCA0CTL1|= UCSSEL_2; // SMCLK
    UCA0BR0=104; // BAUDRATE AT 1 MHz 9600
    UCA0BR1=0;//1MHz 9600
        UCA0MCTL= UCBRS0; // MODULATION UCBRSx=1
        UCA0CTL1&=~UCSWRST; // ** INITIALIZE USCI STATE MACHINE
        IE2&= ~UCA0RXIE; // DISABLE VSCI_A0 RX INTERRUPT

}

void SerialPrintc(unsigned char c)
{
    while(!(IFG2&UCA0TXIFG));  // USCI_A0 TX buffer ready ?
    UCA0TXBUF=c; // TX
}
void SerialPrint(const char *str)
{
    while(*str)
        SerialPrintc(*str++);
}

/// Check that esp returns OK ?
unsigned int Serialfind_OK(void)
{  unsigned int g=0;
   unsigned int ret=0;
while(1)
      {

        if(rxbuffer[g]=='O' && rxbuffer[g+1]=='K')//OK arayan fonksiyon.
              {
                  ret=1;
                  break;
              }

             g++;

            if(g==49)
            {
            g=0;break;
            }

      }
 return ret;
}

unsigned int Serialfind_IP(void)
{  unsigned int L=0;
   unsigned int M=0;
while(1)
      {

        if(rxbuffer[L]=='I' && rxbuffer[L]=='P')//OK arayan fonksiyon.
              {
                  M=1;
                  break;
              }

             L++;

            if(L==49)
            {
            L=0;break;
            }

      }
 return M;
}
// Check that ESP ready to recieve incoming packets
unsigned int Serialfind_packetready(void)//Onay isareti arayan fonksiyon.
{  unsigned int y=0;
   unsigned int don=0;
while(1)
      {

            if(rxbuffer[y]=='>')
              {
                  don=1;
                  break;
              }

             y++;

            if(y==49)
            {
            y=0;break;
            }

      }
 return don;
}
//clear rx buffer
void clr_rxbuff(void)
{ unsigned int p;
  w=0;
  IE2&= ~UCA0RXIE;
  for(p=0;p<50;p++)
  {
   rxbuffer[p]='0';//En son alinan 50 veri temizlendi.
  }
}


#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{
   if(w<50)
   {
     rxbuffer[w]=UCA0RXBUF;//En son alinan 50 karakter verisini diziye yaz.
   }
 else
   {
     IE2&= ~UCA0RXIE;//50 karakter yazdiktan sonra kesmeyi kapat.
     w=0;
   }
   w++;
}
