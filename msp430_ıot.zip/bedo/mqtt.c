/*
 * mqtt.c
 *
 *  Created on: May 12, 2022
 *      Author: user
 */


#include <msp430g2553.h>
#include <string.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "mqtt.h"
#include "uart_serial.h"
#include "lcd.h"
#include "delay.h"
#define ag_ismi "burak"
#define ag_sifre "senveben"

uint16_t ProtocolNameLength;
uint16_t ClientIDLength;
uint16_t Remainlength;

const uint8_t connect = 0x10;
const uint8_t publishCon = 0x30;
const uint8_t subscribeCon = 0x82;
char *protocolName = "MQTT";
const uint8_t level = 0x04;
const uint8_t flag = 0x02;   // 02--> sifresiz
const uint16_t keepAlive =60;
const uint16_t packetID = 0x01;
const uint8_t Qos = 0x00;
char *clientID = "g40";


unsigned int kontrol=0;

void Connect_to_Wifi()
{
        SerialPrint("AT+CWJAP=");
        SerialPrintc('"');
        SerialPrint(ag_ismi);
        SerialPrintc('"');
        SerialPrintc(',');
        SerialPrintc('"');
        SerialPrint(ag_sifre);
        SerialPrintc('"');
        SerialPrint("\r\n");
        }

void Connect_to_Broker()
{
  SerialPrint("AT+CIPSTART=");
  const char tcp[]={'"','T','C','P','"','\0'};
  const char ip[]={'"','i','o','t','.','e','e','.','h','a','c','e','t','t','e','p','e','.','e','d','u','.','t','r','\0'};
  const char port[]={"183"};
  SerialPrint(tcp);
  SerialPrintc(',');
  SerialPrint(ip);
  SerialPrintc(',');
  SerialPrint(port);
  SerialPrint("\r\n");

  while(!Serialfind_OK())  //4sn bpyunca cevap bekle
    {
           kontrol++;
            IE2|=UCA0RXIE;
            if(kontrol==800)
            {
             kontrol=0;
              lcd_yeniden();
              lcd_write("Sunucu baglanmadi!!");
              delay_ms(1000);
              Connect_to_Broker();

            }
           delay_ms(5);
    }
  if(Serialfind_OK())
  {
    lcd_yeniden();
    lcd_write("Sunucuya");
    lcd_go_line(2);
    lcd_write("Baglandi.");
    delay_ms(1000);
}
  //connect packet
      ProtocolNameLength = strlen(protocolName);
      ClientIDLength     = strlen(clientID);

      Remainlength = 2 + ProtocolNameLength + 6 + ClientIDLength;
      uint16_t length = sprintf(tx_buffer,"%c%c%c%c%s%c%c%c%c%c%c%s",(char)connect,(char)Remainlength,(char)(ProtocolNameLength << 8),(char)ProtocolNameLength,protocolName,(char)level,(char)flag,(char)(keepAlive << 8),(char)keepAlive,(char)(ClientIDLength << 8),(char)ClientIDLength,clientID);
      sprintf(tx_buffer,"AT+CIPSEND=%d\r\n",length);
      SerialPrint(tx_buffer);
      delay_ms(100);
      IE2|=UCA0RXIE;
      if(Serialfind_packetready()){
          sprintf(tx_buffer,"%c%c%c%c%s%c%c%c%c%c%c%s",(char)connect,(char)Remainlength,(char)(ProtocolNameLength << 8),(char)ProtocolNameLength,protocolName,(char)level,(char)flag,(char)(keepAlive << 8),(char)keepAlive,(char)(ClientIDLength << 8),(char)ClientIDLength,clientID);

          SerialPrint(tx_buffer);
          delay_ms(10);
          lcd_yeniden();
          lcd_write("Connected to broker");
      }
      else {
          lcd_yeniden();
          lcd_write("Basarisiz!!");
          SerialPrint("AT+CIPCLOSE\r\n");
          delay_ms(500);
          Connect_to_Broker();
      }
}

void publish(char *topic, char *message)
{
    uint16_t topiclength = strlen(topic);
    uint16_t remainlength = 2+topiclength+strlen(message);// packetIDlength(2) + topiclengthdata(2)+topiclength+Qos
    int length = sprintf(tx_buffer,"%c%c%c%c%s%s",(char)publishCon,(char)remainlength,(char)(topiclength << 8),(char)topiclength,topic,message);
    sprintf(tx_buffer,"AT+CIPSEND=%d\r\n",length);
    SerialPrint(tx_buffer);
    delay_ms(100);
    if(Serialfind_packetready()){
    sprintf(tx_buffer,"%c%c%c%c%s%s",(char)publishCon,(char)remainlength,(char)(topiclength << 8),(char)topiclength,topic,message);
    const char tmp04 = (const char)tx_buffer;
    SerialPrint(tmp04);
    }
    else {
        lcd_yeniden();
        lcd_write("Not published");
        delay_ms(500);
        publish(topic,message);
    }

    delay_ms(10);
}
